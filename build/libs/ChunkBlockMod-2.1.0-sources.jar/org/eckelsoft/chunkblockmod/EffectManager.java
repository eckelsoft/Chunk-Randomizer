package org.eckelsoft.chunkblockmod;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_124;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1294;
import net.minecraft.class_1923;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_6880;
import net.minecraft.class_7923;

public class EffectManager {
    private static final List<class_6880<class_1291>> VALID_EFFECTS = new ArrayList<>();

    static {
        for (class_6880<class_1291> effect : class_7923.field_41174.method_40295()) {
            if (!effect.equals(class_1294.field_5919) &&
                    !effect.equals(class_1294.field_38092) &&
                    !effect.equals(class_1294.field_5916)) {
                VALID_EFFECTS.add(effect);
            }
        }
    }

    public static void applyChunkEffect(class_3222 player, class_1923 chunkPos) {
        if (VALID_EFFECTS.isEmpty()) return;

        long seed = (long) chunkPos.field_9181 * 49632L + (long) chunkPos.field_9180 * 32517L;
        Random chunkRandom = new Random(seed);

        class_6880<class_1291> effect = VALID_EFFECTS.get(chunkRandom.nextInt(VALID_EFFECTS.size()));
        class_3218 world = player.method_51469();

        int amplifier;
        if (effect.comp_349().method_5561()) {
            amplifier = chunkRandom.nextInt(2);

            effect.comp_349().method_5572(world, player, amplifier);

            if (ModState.getDebugLevel() == 3) {
                player.method_7353(class_2561.method_43470("§d[LOG] Instant-Effect: " + effect.comp_349().method_5560().getString()).method_27692(class_124.field_1076), false);
            }
        } else {
            amplifier = chunkRandom.nextInt(5);
            int durationTicks = chunkRandom.nextBoolean() ? (20 * 8) : (20 * 16);
            player.method_6092(new class_1293(effect, durationTicks, amplifier));

            if (ModState.getDebugLevel() == 3) {
                player.method_7353(class_2561.method_43470("§d[LOG] Effect: " + effect.comp_349().method_5560().getString() + " (Duration: " + (durationTicks/20) + "s, Amp: " + amplifier + ")").method_27692(class_124.field_1076), false);
            }
        }
    }
}