package org.eckelsoft.chunkblockmod;

import net.minecraft.block.*;
import net.minecraft.class_124;
import net.minecraft.class_2170;
import net.minecraft.class_2248;
import net.minecraft.class_2257;
import net.minecraft.class_2561;
import net.minecraft.command.argument.*;
import com.mojang.brigadier.arguments.BoolArgumentType;
import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

public class Chunkblockmod implements ModInitializer {
    @Override
    public void onInitialize() {
        ServerTickEvents.END_SERVER_TICK.register(server -> {
            long timeMs = ModState.getElapsedTime();
            long sec = (timeMs / 1000) % 60;
            long min = (timeMs / (1000 * 60)) % 60;
            long hr = (timeMs / (1000 * 60 * 60));
            String timeStr = String.format("%02d:%02d:%02d", hr, min, sec);

            String prefix = ModState.getTimerPrefix().isEmpty() ? "" : ModState.getTimerPrefix() + " ";
            String suffix = ModState.getTimerSuffix().isEmpty() ? "" : " " + ModState.getTimerSuffix();
            String fullDisplay = prefix + timeStr + suffix;

            class_2561 message = !ModState.isActive() ?
                    (timeMs == 0 ?
                            class_2561.method_43470("Type \"/rc start\" to begin. Config: \"/rc \"").method_27692(class_124.field_1054) :
                            class_2561.method_43470("Paused: " + fullDisplay).method_27692(class_124.field_1061)) :
                    class_2561.method_43470(fullDisplay).method_27692(class_124.field_1060);

            if (ModState.isTimerVisible()) {
                server.method_3760().method_14571().forEach(p -> p.method_7353(message, true));
            }
            server.method_3738().forEach(ChunkReplacementManager::tick);
        });

        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            dispatcher.register(class_2170.method_9247("rc")
                    .then(class_2170.method_9247("start")
                            .executes(c -> {
                                ModState.setActive(true, c.getSource().method_9211());
                                return 1;
                            })
                    )

                    .then(class_2170.method_9247("stop")
                            .executes(c -> {
                                ModState.setActive(false, c.getSource().method_9211());
                                return 1;
                            })
                    )

                    .then(class_2170.method_9247("fluids")
                            .then(class_2170.method_9244("enabled", BoolArgumentType.bool())
                                    .executes(c -> {
                                        boolean enabled = BoolArgumentType.getBool(c, "enabled");
                                        ModState.setReplaceFluids(enabled);
                                        c.getSource().method_9226(() -> class_2561.method_43470("Replace Fluids: " + enabled), false);
                                        return 1;
                                    })
                            )
                    )

                    .then(class_2170.method_9247("reset")
                            .executes(c -> {
                                ModState.resetTimer();
                                c.getSource().method_9226(() -> class_2561.method_43470("Timer reset to 00:00:00"), false);
                                return 1;
                            })
                    )

                    .then(class_2170.method_9247("effects")
                            .executes(c -> {
                                ModState.setEffectsEnabled(!ModState.areEffectsEnabled());
                                c.getSource().method_9226(
                                        () -> class_2561.method_43470("Effects: " + ModState.areEffectsEnabled()), false
                                );
                                return 1;
                            })
                    )

                    .then(class_2170.method_9247("exclude")
                            .requires(source -> source.method_9259(2)) // Nur für Admins/OPs
                            .executes(c -> {
                                c.getSource().method_9226(() -> class_2561.method_43470("USE: /rc exclude add <block> OR: /rc exclude clear"), false);
                                return 1;
                            })
                            .then(class_2170.method_9247("add")
                                    .then(class_2170.method_9244("block", class_2257.method_9653(registryAccess))
                                            .executes(c -> {
                                                class_2248 block = class_2257.method_9655(c, "block").method_9494().method_26204();
                                                ModState.addToBlacklist(block);
                                                c.getSource().method_9226(() -> class_2561.method_43470("§6[ChunkMod] §f" + block.method_9518().getString() + " will be skipped from now on."), true);
                                                return 1;
                                            })
                                    )
                            )
                            .then(class_2170.method_9247("clear")
                                    .executes(c -> {
                                        ModState.clearCustomBlacklist();
                                        ChunkReplacementManager.reloadBlocks(c.getSource().method_9225());
                                        c.getSource().method_9226(() -> class_2561.method_43470("Custom blacklist cleared."), true);
                                        return 1;
                                    })
                            )
                    )

                    .then(class_2170.method_9247("debug")
                            .executes(c -> {
                                ModState.setDebugLevel(0);
                                c.getSource().method_9226(() -> class_2561.method_43470("Debug mode: OFF"), false);
                                return 1;
                            })
                            .then(class_2170.method_9244("level", IntegerArgumentType.integer(0, 3))
                                    .executes(c -> {
                                        int level = IntegerArgumentType.getInteger(c, "level");
                                        ModState.setDebugLevel(level);
                                        String msg;
                                        switch (level) {
                                            case 1 -> msg = "ON (Mobs only)";
                                            case 2 -> msg = "ON (Chunk Blocktype only)";
                                            case 3 -> msg = "ON (Effects/Buffs only)";
                                            default -> msg = "OFF";
                                        }
                                        c.getSource().method_9226(
                                                () -> class_2561.method_43470("Debug Level set to: " + msg), false
                                        );
                                        return 1;
                                    })
                            )
                    )

                    .then(class_2170.method_9247("spawnmonster")
                            .then(class_2170.method_9247("chunks")
                                    .then(class_2170.method_9244("val", IntegerArgumentType.integer(1))
                                            .executes(c -> {
                                                ModState.setSpawnInterval(
                                                        IntegerArgumentType.getInteger(c, "val")
                                                );
                                                return 1;
                                            })
                                    )
                            )
                            .then(class_2170.method_9247("max")
                                    .then(class_2170.method_9244("val", IntegerArgumentType.integer(1, 64))
                                            .executes(c -> {
                                                ModState.setMaxMobs(
                                                        IntegerArgumentType.getInteger(c, "val")
                                                );
                                                return 1;
                                            })
                                    )
                            )
                    )

                    .then(class_2170.method_9247("timer")
                            .then(class_2170.method_9247("prefix")
                                    .then(class_2170.method_9244("text", StringArgumentType.greedyString())
                                            .executes(c -> {
                                                ModState.setTimerPrefix(
                                                        StringArgumentType.getString(c, "text")
                                                );
                                                return 1;
                                            })
                                    )
                            )
                            .then(class_2170.method_9247("suffix")
                                    .then(class_2170.method_9244("text", StringArgumentType.greedyString())
                                            .executes(c -> {
                                                ModState.setTimerSuffix(
                                                        StringArgumentType.getString(c, "text")
                                                );
                                                return 1;
                                            })
                                    )
                            )
                            .executes(c -> {
                                ModState.setTimerVisible(!ModState.isTimerVisible());
                                return 1;
                            })
                    )
            );
        });
    }
}