package org.eckelsoft.chunkblockmod;

import net.minecraft.class_1887;
import net.minecraft.class_2248;
import net.minecraft.class_2960;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public class ModTags {
    public static final class_6862<class_2248> PRESERVED_BLOCKS = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("chunkblockmod", "preserved_blocks"));
    public static final class_6862<class_2248> INVALID_REPLACEMENT_BLOCKS = class_6862.method_40092(class_7924.field_41254, class_2960.method_60655("chunkblockmod", "invalid_replacements"));
    public static final class_6862<class_1887> CHUNK_WALKER_EXCLUSIVE_SET = class_6862.method_40092(class_7924.field_41265, class_2960.method_60655("chunkblockmod", "exclusive/chunk_walker"));
}