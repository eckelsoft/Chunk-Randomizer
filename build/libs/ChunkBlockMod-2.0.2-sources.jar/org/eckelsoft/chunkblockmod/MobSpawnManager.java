package org.eckelsoft.chunkblockmod;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import net.minecraft.class_124;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3730;
import net.minecraft.class_7923;

public class MobSpawnManager {
    private static final List<class_1299<?>> DYNAMIC_MOB_POOL = new ArrayList<>();
    private static final Random RANDOM = new Random();

    static {
        for (class_1299<?> type : class_7923.field_41177) {
            if (type != class_1299.field_6116 &&
                    type != class_1299.field_33456 &&
                    type != class_1299.field_6083 &&
                    type != class_1299.field_6103) {

                if (type.method_5891() != class_1311.field_17715) {
                    DYNAMIC_MOB_POOL.add(type);
                }
            }
        }
        DYNAMIC_MOB_POOL.add(class_1299.field_6119);
        DYNAMIC_MOB_POOL.add(class_1299.field_6112);
    }

    public static void triggerSurpriseSpawn(class_3218 world, class_3222 player) {
        if (DYNAMIC_MOB_POOL.isEmpty()) return;

        int amount = RANDOM.nextInt(ModState.getMaxMobs()) + 1;
        class_2338 playerPos = player.method_24515();

        for (int i = 0; i < amount; i++) {
            class_1299<?> type = DYNAMIC_MOB_POOL.get(RANDOM.nextInt(DYNAMIC_MOB_POOL.size()));
            class_2338 spawnPos = playerPos.method_10069(RANDOM.nextInt(10) - 5, 1, RANDOM.nextInt(10) - 5);

            try {
                type.method_47821(world, spawnPos, class_3730.field_16467);
            } catch (Exception e) {
                // ignore
            }
        }

        if (ModState.getDebugLevel() == 1) {
            player.method_7353(class_2561.method_43470("§6" + amount + " mobs have spawned!").method_27692(class_124.field_1065), false);
        }
    }
}