package org.eckelsoft.chunkblockmod;

public class ModState {
    private static boolean active = false;
    private static int debugLevel = 1;
    private static boolean timerVisible = true;
    private static boolean effectsEnabled = true;
    private static int spawnInterval = 16;
    private static int maxMobs = 8;
    private static boolean replaceFluids = false;

    private static long startTime = 0;
    private static long elapsedBeforeStop = 0;
    private static String timerPrefix = "";
    private static String timerSuffix = "";

    public static boolean isActive() { return active; }
    public static void setActive(boolean active, net.minecraft.server.MinecraftServer server) {
        if (active && !ModState.active) {
            if (getElapsedTime() == 0 && server != null) {
                server.method_3760().method_14571().forEach(player -> {
                    net.minecraft.class_1799 boots = new net.minecraft.class_1799(net.minecraft.class_1802.field_8285);
                    boots.method_57379(net.minecraft.class_9334.field_49631,
                            net.minecraft.class_2561.method_43470("Chunk Walker").method_27692(net.minecraft.class_124.field_1075));

                    player.method_31548().method_7394(boots);
                });
            }
            startTime = System.currentTimeMillis();
        } else if (!active && ModState.active) {
            elapsedBeforeStop += (System.currentTimeMillis() - startTime);
        }
        ModState.active = active;
    }

    public static int getDebugLevel() { return debugLevel; }
    public static void setDebugLevel(int level) { debugLevel = level; }
    public static boolean isTimerVisible() { return timerVisible; }
    public static void setTimerVisible(boolean visible) { ModState.timerVisible = visible; }
    public static boolean areEffectsEnabled() { return effectsEnabled; }
    public static void setEffectsEnabled(boolean enabled) { effectsEnabled = enabled; }
    public static int getSpawnInterval() { return spawnInterval; }
    public static void setSpawnInterval(int interval) { spawnInterval = interval; }
    public static int getMaxMobs() { return maxMobs; }
    public static void setMaxMobs(int max) { maxMobs = max; }
    public static boolean shouldReplaceFluids() { return replaceFluids; }
    public static void setReplaceFluids(boolean replace) { replaceFluids = replace; }
    public static void resetTimer() { startTime = System.currentTimeMillis(); elapsedBeforeStop = 0; }
    public static long getElapsedTime() {
        if (!active) return elapsedBeforeStop;
        return elapsedBeforeStop + (System.currentTimeMillis() - startTime);
    }
    public static String getTimerPrefix() { return timerPrefix; }
    public static void setTimerPrefix(String prefix) { timerPrefix = prefix; }
    public static String getTimerSuffix() { return timerSuffix; }
    public static void setTimerSuffix(String suffix) { timerSuffix = suffix; }
}